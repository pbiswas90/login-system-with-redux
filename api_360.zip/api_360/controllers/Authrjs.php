<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/NEW_REST_Controller.php';

use \Firebase\JWT\JWT;

class Authrjs extends MY_REST_Controller
{
    private $logdata = array();

    function __construct()
    {

        parent::__construct();
        //echo 'hello'; exit;
        $this->load->library('form_validation');
        $this->load->model('Authrjs_model');

   

       

        $this->logdata['called_on'] = date('Y-m-d H:i:s', time());
        $this->logdata['process_start_time'] = date('Y-m-d H:i:s');
        $this->logdata['version'] = $this->input->get_request_header('version');

    }

    

   
   
    /**
     * SEND OTP FOR LOGIN & REGISTRATION
     */
    public function loginEmail_post()
    {


        $this->form_validation->set_rules('email', 'Email Id', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == false) {
            $err_arr = $this->form_validation->error_array();
            $message = implode(" & ", $err_arr);

            $output['error'] = $message;
            $phone_no = $this->post('email');
            $this->logdata['username'] = $phone_no;
            $this->logdata['response'] = REST_Controller::HTTP_NON_AUTHORITATIVE_INFORMATION;
            $this->logdata['message'] = $message;
            $this->logdata['response_on'] = date('Y-m-d H:i:s', time());

            $this->set_response($output, $message, REST_Controller::HTTP_NON_AUTHORITATIVE_INFORMATION, $this->logdata); //This is the
        } else {


           

                $authresponse = $this->Authrjs_model->validation_email_password();
                //print_r($authresponse); exit;

                if ($authresponse['type'] == 'Login') {  //redirect to login page for again

                    $output['status'] = 1;
                    $message = $authresponse['message'];
                    $output['token'] = '';
                    $output['refresh_token'] = '';
                    $phone_no = $this->post('phone_no');
                    $this->logdata['username'] = $phone_no;
                    $this->logdata['response'] = REST_Controller::HTTP_NON_AUTHORITATIVE_INFORMATION;
                    $this->logdata['message'] = $message;
                    $this->logdata['response_on'] = date('Y-m-d H:i:s', time());

                    $this->set_response($output, $message, REST_Controller::HTTP_NON_AUTHORITATIVE_INFORMATION, $this->logdata); //This is t
                }

                if ($authresponse['type'] == 'Error') {  //No is verified and redirecting to registration page as because new no


                    $output['token'] = '';
                    $output['refresh_token'] = '';
                    $output['status'] = 2;

                    $message = $authresponse['message'];

                    $phone_no = $this->post('phone_no');
                    $this->logdata['username'] = $phone_no;
                    $this->logdata['response'] = REST_Controller::HTTP_NON_AUTHORITATIVE_INFORMATION;
                    $this->logdata['message'] = $message;
                    $this->logdata['response_on'] = date('Y-m-d H:i:s', time());
                    /**
                     * For api detail table
                     */
                    $this->set_response($output, $message, REST_Controller::HTTP_NON_AUTHORITATIVE_INFORMATION, $this->logdata);
                }

                if ($authresponse['type'] == 'Dashboard') {  //Existing user logging in and redirecting to dashboard

                   
                    $date = new DateTime();
                    $token = array(
                        "iss" => "https://doctor.clirnet.com",
                        "aud" => "https://doctor.clirnet.com",
                        "userdetail" => array("user_master_id" => $authresponse['user_master_id'], "username" => $authresponse['user_name']),
                        "iat" => $date->getTimestamp(),
                        "exp" => $date->getTimestamp() + 60 //To here is to generate token
                    );
                    $refresh_token = array(
                        "iss" => "https://doctor.clirnet.com",
                        "aud" => "https://doctor.clirnet.com",
                        "userdetail" => array("user_master_id" => $authresponse['user_master_id'], "username" => $authresponse['user_name']),
                        "iat" => $date->getTimestamp(),
                        "exp" => $date->getTimestamp() + 60 * 60 * 30 //To here is to generate token
                    );

                    $output['status'] = 3;
                    $output['token'] = JWT::encode($token, $this->config->item('jwt_key')); //This is the output token
                    $output['refresh_token'] = JWT::encode($refresh_token, $this->config->item('jwt_key')); //This is the output token
                    $message = 'Authentication successful';

                    //$authresponse = $this->Authrjs_model->update_device_id($authresponse['user_master_id'],$this->input->post('device_id'));
                    ////Updating device id for the user

                    $this->logdata['doctor_id'] = $authresponse['user_master_id'];
                    $this->logdata['response'] = REST_Controller::HTTP_OK;
                    $this->logdata['message'] = $message;
                    $this->logdata['response_on'] = date('Y-m-d H:i:s', time());

                    $this->set_response($output, $message, REST_Controller::HTTP_OK, $this->logdata); //This is the respon if success
                }


            

        }


    }
    


}

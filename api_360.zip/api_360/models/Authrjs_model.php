<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Authrjs_model extends CI_Model
{

    function __construct()
    {

        parent::__construct();
        //Table Name
        $this->table_name = "users";
    }

   





    /**
     * @return array|bool
     */
    function validation_email_password()
    {


        $qry = "SELECT 
                user_master_test.*,user_detail_test.first_name,user_detail_test.last_name 
        FROM 
        user_master_test 
        JOIN user_detail_test ON user_detail_test.user_master_id=user_master_test.user_master_id
        WHERE 
        user_master_test.email = ? 
        AND 
        user_master_test.password = ? 
        AND 
        user_master_test.status = ?";

        $query = $this->db->query($qry, array($this->input->post('email'), md5($this->input->post('password')), 3));
        //echo  $this->db->last_query(); exit();
        $row = $query->row();
        if ($query->num_rows() > 0) {


            $response['type'] = "Dashboard";
            $response['message'] = "Login Successfull.";
            $response['user_master_id'] = $row->user_master_id;
           
            $response['user_name'] = $row->user_name;
            $response['last_name'] = $row->last_name;
            $response['first_name'] = $row->first_name;

            




        } else {

            $response['type'] = "Error";
            $response['message'] = "Email password mismatched";

        }
        return $response;


    }

   


}

?>